from flask import Flask, render_template, jsonify, request
import requests
import numpy as np
import pandas as pd
import time
import joblib
import threading
from datetime import datetime
import random

# -------------------------------
# FLASK INIT
# -------------------------------
app = Flask(__name__)

# -------------------------------
# LOAD MODEL
# -------------------------------
try:
    model = joblib.load('xgboost_heart_model.joblib')
    le = joblib.load('label_encoder.joblib')
    MODEL_LOADED = True
    print(f"✅ Model loaded. Classes: {le.classes_}")
except:
    MODEL_LOADED = False
    model = None
    le = None
    print("⚠️ Model not loaded — running in dummy mode")

# -------------------------------
# LOAD DATASET FOR SIMULATION
# -------------------------------
try:
    dataset = pd.read_csv('Dataset.csv')

    normal_data       = dataset[dataset['Label'].str.lower().str.contains('normal',    na=False) &
                                ~dataset['Label'].str.lower().str.contains('myocardial|arytho', na=False)]
    arytho_data       = dataset[dataset['Label'].str.lower().str.contains('arytho',    na=False)]
    mi_data           = dataset[dataset['Label'].str.lower().str.contains('myocardial', na=False)]

    SIMULATION_AVAILABLE = True
    print(f"✅ Dataset loaded: {len(normal_data)} Normal | {len(arytho_data)} Arythometic | {len(mi_data)} Myocardial Infarction")
except Exception as e:
    print(f"⚠️ Dataset not loaded: {e}")
    SIMULATION_AVAILABLE = False
    normal_data = arytho_data = mi_data = None

# -------------------------------
# API URLs
# -------------------------------
DATA_URL = "https://iotcloud22.in/4686/light.json"
POST_URL = "https://iotcloud22.in/4686/post_value1.php"

# -------------------------------
# COLUMN MAPPING
# -------------------------------
columns = [
    'Heartrate',
    'Beatspacing',
    'Rythumvariation',
    'contractiontime',
    'Baseline',
    'Signal',
    'Variability'
]

# -------------------------------
# GLOBAL VARIABLES — REAL MONITOR
# -------------------------------
is_collecting = False
collection_thread = None
latest_data = {
    "current_values": [0, 0, 0, 0, 0, 0, 0],
    "prediction": "Waiting...",
    "last_update": "",
    "sample_count": 0,
    "is_collecting": False
}

# -------------------------------
# GLOBAL VARIABLES — DEMO (/1)
# -------------------------------
is_demo_running = False
demo_thread = None
demo_data = {
    "current_values": [0, 0, 0, 0, 0, 0, 0],
    "prediction": "Waiting...",
    "last_update": "",
    "sample_count": 0,
    "is_collecting": False,
    "mode": "stopped"   # "normal" | "arythometic" | "myocardial_infarction" | "stopped"
}

# -------------------------------
# FUNCTION: FETCH LIVE DATA
# -------------------------------
def fetch_live_data():
    try:
        response = requests.get(DATA_URL, timeout=5)
        print("RAW RESPONSE:", response.text)
        data = response.json()
        values = [
            float(data.get('value1', 0)),
            float(data.get('value2', 0)),
            float(data.get('value3', 0)),
            float(data.get('value4', 0)),
            float(data.get('value5', 0)),
            float(data.get('value6', 0)),
            float(data.get('value7', 0))
        ]
        return values
    except Exception as e:
        print(f"Error fetching data: {e}")
        return [0, 0, 0, 0, 0, 0, 0]

# -------------------------------
# FUNCTION: GENERATE DATA BY MODE (3 classes)
# -------------------------------
def generate_data_by_mode(mode):
    """
    mode: 'normal' | 'arythometic' | 'myocardial_infarction'
    Pulls a random row from the matching dataset partition.
    Falls back to hand-crafted dummy ranges if dataset is unavailable.
    """
    # ---- fallback dummy data ----
    dummy = {
        "normal": [
            random.uniform(60, 75),
            random.uniform(0.6, 0.8),
            random.uniform(0.02, 0.05),
            random.uniform(0.3, 0.4),
            random.uniform(0.5, 0.7),
            random.uniform(0.8, 1.2),
            random.uniform(10, 20)
        ],
        "arythometic": [
            random.uniform(45, 58),       # irregular / low HR
            random.uniform(0.9, 1.3),     # long beat spacing
            random.uniform(0.10, 0.22),   # high rhythm variation
            random.uniform(0.25, 0.35),
            random.uniform(0.4, 0.6),
            random.uniform(0.6, 0.9),
            random.uniform(28, 50)        # high variability
        ],
        "myocardial_infarction": [
            random.uniform(95, 130),      # elevated HR
            random.uniform(0.2, 0.4),     # short beat spacing
            random.uniform(0.08, 0.20),
            random.uniform(0.05, 0.15),   # short contraction
            random.uniform(0.1, 0.3),     # low baseline
            random.uniform(0.2, 0.5),     # weak signal
            random.uniform(35, 60)
        ]
    }

    if not SIMULATION_AVAILABLE:
        return dummy.get(mode, dummy["normal"])

    # ---- real dataset rows ----
    source_map = {
        "normal":                normal_data,
        "arythometic":           arytho_data,
        "myocardial_infarction": mi_data
    }
    source = source_map.get(mode)

    try:
        if source is not None and len(source) > 0:
            sample = source.sample(1).iloc[0]
            values = []
            for col in columns:
                values.append(float(sample[col]) if col in sample.index else 0.0)
            # tiny jitter
            values = [v + random.uniform(-abs(v)*0.05, abs(v)*0.05) if v != 0 else random.uniform(0, 1)
                      for v in values]
            return values
    except Exception as e:
        print(f"Error generating data for mode '{mode}': {e}")

    return dummy.get(mode, dummy["normal"])

# -------------------------------
# FUNCTION: MAKE PREDICTION
# -------------------------------
def make_prediction(avg_values):
    if MODEL_LOADED and model is not None and le is not None:
        try:
            input_df = pd.DataFrame([avg_values], columns=columns)
            prediction = model.predict(input_df)
            label = le.inverse_transform(prediction)[0]
            return label
        except Exception as e:
            print(f"Prediction error: {e}")
            return "Error"
    else:
        # dummy fallback
        hr = avg_values[0]
        if hr > 90:
            return "Myocardial Infarction"
        elif hr < 58:
            return "Arythometic"
        else:
            return "Normal"

# -------------------------------
# FUNCTION: SEND PREDICTION TO SERVER
# -------------------------------
def send_prediction_to_server(prediction):
    try:
        pred_str = str(prediction).lower().strip()

        if 'normal' in pred_str and 'myocardial' not in pred_str:
            value = 0
        elif 'arytho' in pred_str:
            value = 1
        else:  # myocardial infarction
            value = 2

        params = {'value1': value}
        response = requests.post(POST_URL, data=params, timeout=5)
        print(f"Sent prediction '{prediction}' as value1={value}. Status: {response.status_code}")
        return True
    except Exception as e:
        print(f"Error sending prediction: {e}")
        return False

# -------------------------------
# FUNCTION: COLLECTION LOOP (REAL)
# -------------------------------
def collection_loop():
    global is_collecting, latest_data

    while is_collecting:
        collected_samples = []
        print(f"\n🔄 Starting new collection cycle (10 samples)...")

        for i in range(10):
            if not is_collecting:
                break
            values = fetch_live_data()
            collected_samples.append(values)
            latest_data["current_values"] = values
            latest_data["sample_count"] = i + 1
            latest_data["last_update"] = datetime.now().strftime("%H:%M:%S")
            latest_data["is_collecting"] = is_collecting
            print(f"  Sample {i+1}/10: Heartrate={values[0]:.2f}, Variability={values[6]:.2f}")
            if i < 9:
                time.sleep(2)

        if len(collected_samples) == 10 and is_collecting:
            data_array = np.array(collected_samples, dtype=float)
            avg_values = np.mean(data_array, axis=0)
            prediction = make_prediction(avg_values)
            latest_data["prediction"] = prediction
            latest_data["is_collecting"] = is_collecting
            send_prediction_to_server(prediction)
            print(f"\n✅ Cycle complete! Prediction: {prediction}")

        if is_collecting:
            print("\n⏳ Waiting 3 seconds before next cycle...\n")
            time.sleep(3)

    latest_data["is_collecting"] = False
    latest_data["sample_count"] = 0

# -------------------------------
# FUNCTION: DEMO LOOP (for /1)
# -------------------------------
def demo_loop():
    global is_demo_running, demo_data

    while is_demo_running:
        collected_samples = []
        current_mode = demo_data["mode"]
        print(f"\n🔄 Demo cycle — Mode: {current_mode.upper()}...")

        for i in range(10):
            if not is_demo_running:
                break
            values = generate_data_by_mode(current_mode)
            collected_samples.append(values)
            demo_data["current_values"] = values
            demo_data["sample_count"] = i + 1
            demo_data["last_update"] = datetime.now().strftime("%H:%M:%S")
            demo_data["is_collecting"] = is_demo_running
            print(f"  Demo Sample {i+1}/10 [{current_mode}]: Heartrate={values[0]:.2f}")
            if i < 9:
                time.sleep(2)

        if len(collected_samples) == 10 and is_demo_running:
            data_array = np.array(collected_samples, dtype=float)
            avg_values = np.mean(data_array, axis=0)
            prediction = make_prediction(avg_values)
            demo_data["prediction"] = prediction
            demo_data["is_collecting"] = is_demo_running
            print(f"\n✅ Demo cycle complete! Prediction: {prediction}")

        if is_demo_running:
            time.sleep(3)

# -------------------------------
# ROUTE: HOME PAGE (REAL)
# -------------------------------
@app.route('/')
def home():
    return render_template('index.html')

# -------------------------------
# ROUTE: DEMO PAGE (/1)
# -------------------------------
@app.route('/1')
def demo_page():
    return render_template('index2.html')

# -------------------------------
# ROUTE: START COLLECTION (REAL)
# -------------------------------
@app.route('/start')
def start_collection():
    global is_collecting, collection_thread
    if not is_collecting:
        is_collecting = True
        latest_data["is_collecting"] = True
        collection_thread = threading.Thread(target=collection_loop, daemon=True)
        collection_thread.start()
        return jsonify({"status": "success", "message": "Collection started"})
    return jsonify({"status": "info", "message": "Already running"})

# -------------------------------
# ROUTE: STOP COLLECTION (REAL)
# -------------------------------
@app.route('/stop')
def stop_collection():
    global is_collecting
    if is_collecting:
        is_collecting = False
        latest_data["is_collecting"] = False
        return jsonify({"status": "success", "message": "Collection stopped"})
    return jsonify({"status": "info", "message": "Not running"})

# -------------------------------
# ROUTE: GET LIVE DATA (REAL)
# -------------------------------
@app.route('/get_live_data')
def get_live_data():
    return jsonify(latest_data)

# -------------------------------
# ROUTE: START DEMO WITH A SPECIFIC CLASS
#   POST /1/simulate   body: { "mode": "normal" | "arythometic" | "myocardial_infarction" }
# -------------------------------
@app.route('/1/simulate', methods=['POST'])
def simulate():
    global is_demo_running, demo_thread, demo_data

    data = request.get_json(force=True)
    mode = data.get('mode', 'normal')

    valid_modes = ['normal', 'arythometic', 'myocardial_infarction']
    if mode not in valid_modes:
        return jsonify({"status": "error", "message": f"Invalid mode. Choose from {valid_modes}"}), 400

    # Stop any running demo first
    is_demo_running = False
    if demo_thread and demo_thread.is_alive():
        demo_thread.join(timeout=1)

    # Reset and start fresh with chosen mode
    demo_data["mode"] = mode
    demo_data["prediction"] = "Collecting..."
    demo_data["sample_count"] = 0
    demo_data["is_collecting"] = True

    is_demo_running = True
    demo_thread = threading.Thread(target=demo_loop, daemon=True)
    demo_thread.start()

    return jsonify({"status": "success", "mode": mode})

# -------------------------------
# ROUTE: STOP DEMO
# -------------------------------
@app.route('/1/stop', methods=['GET', 'POST'])
def stop_demo():
    global is_demo_running, demo_data
    is_demo_running = False
    demo_data["is_collecting"] = False
    demo_data["mode"] = "stopped"
    return jsonify({"status": "success", "message": "Demo stopped"})

# -------------------------------
# ROUTE: GET DEMO DATA
# -------------------------------
@app.route('/1/get_data')
def get_demo_data():
    return jsonify(demo_data)

# -------------------------------
# RUN APP
# -------------------------------
if __name__ == '__main__':
    print("\n" + "="*50)
    print("💓 CARDIAC MONITORING SYSTEM")
    print("="*50)
    print(f"📡 Data URL: {DATA_URL}")
    print(f"📤 Post URL: {POST_URL}")
    print(f"🤖 Model: {'Loaded' if MODEL_LOADED else 'Dummy Mode'}")
    print(f"📊 Dataset: {'Loaded' if SIMULATION_AVAILABLE else 'Not Available'}")
    print("\n🌐 Access:")
    print("   - Live Monitor : http://127.0.0.1:5000")
    print("   - Demo Page    : http://127.0.0.1:5000/1")
    print("="*50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)