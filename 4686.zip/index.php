<?php
include("connection.php");
$sql = "SELECT * FROM `4686` ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$value1 = $row["value1"];
$value2 = $row["value2"];
$value3 = $row["value3"];
$value4 = $row["value4"];
$value5 = $row["value5"];
$value6 = $row["value6"];
$value7 = $row["value7"];
$date = $row["reading_time"];

$sql1 = "SELECT * FROM `4686_1` ORDER BY id DESC LIMIT 1";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);

$value11 = $row1["value1"];
$date1 = $row1["reading_time"];

$value11 = $row1["value1"];
$date1 = $row1["reading_time"];

// CORRECT condition - check if value is set AND equals 0 or 1
if($value11 === 0 || $value11 === '0') {
    $prediction_display = "Normal";
    $prediction_color = "text-green-400";
} elseif($value11 === 1 || $value11 === '1') {
    $prediction_display = "Arrhythmic";
    $prediction_color = "text-green-400";
} elseif($value11 === 2 || $value11 === '2') {
    $prediction_display = "Myocardial Infarction";
    $prediction_color = "text-green-400";
} 
// Graph data for 50 points
$sql12 = "SELECT * FROM `4686` ORDER BY id DESC LIMIT 50";
$result12 = mysqli_query($conn, $sql12);
$data_value1 = [];
$data_value2 = [];
$data_value3 = [];
$data_value4 = [];
$data_value5 = [];
$data_value6 = [];
$data_value7 = [];
$data_time = [];

if(mysqli_num_rows($result12) > 0) {
    while($row12 = mysqli_fetch_assoc($result12)) {
        array_unshift($data_value1, $row12["value1"]);  
        array_unshift($data_value2, $row12["value2"]);  
        array_unshift($data_value3, $row12["value3"]);  
        array_unshift($data_value4, $row12["value4"]);  
        array_unshift($data_value5, $row12["value5"]);  
        array_unshift($data_value6, $row12["value6"]);  
        array_unshift($data_value7, $row12["value7"]);  
        array_unshift($data_time, date('H:i:s', strtotime($row12["reading_time"])));  
    }
}

// Pad arrays with zeros if less than 50 points
$pad_length = 50;
$data_value1 = array_pad($data_value1, $pad_length, 0);
$data_value2 = array_pad($data_value2, $pad_length, 0);
$data_value3 = array_pad($data_value3, $pad_length, 0);
$data_value4 = array_pad($data_value4, $pad_length, 0);
$data_value5 = array_pad($data_value5, $pad_length, 0);
$data_value6 = array_pad($data_value6, $pad_length, 0);
$data_value7 = array_pad($data_value7, $pad_length, 0);
$data_time = array_pad($data_time, $pad_length, '');

// Calculate health metrics
$heart_rate_status = $value1 > 100 ? 'High' : ($value1 < 60 ? 'Low' : 'Normal');
$heart_rate_color = $value1 > 100 ? 'text-red-400' : ($value1 < 60 ? 'text-yellow-400' : 'text-green-400');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Cardiac Diagnosis Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="5">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://rsms.me/inter/inter.css">
    
    <!-- Animation -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
    <!-- Chart.js for data visualization -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #3b82f6;
            --secondary: #8b5cf6;
            --tertiary: #ec4899;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            color: #f8fafc;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        }
        
        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.2);
            border-color: rgba(59, 130, 246, 0.3);
        }
        
        .gradient-text {
            background: linear-gradient(90deg, var(--primary), var(--secondary), var(--tertiary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            background-size: 200% auto;
            animation: gradient 3s ease infinite;
        }
        
        @keyframes gradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        
        .heartbeat {
            animation: heartbeat 1.5s ease-in-out infinite;
        }
        
        @keyframes heartbeat {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .status-badge {
            padding: 0.35rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 600;
            backdrop-filter: blur(10px);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .data-point {
            animation: glow 2s infinite alternate;
        }
        
        @keyframes glow {
            from { filter: drop-shadow(0 0 2px rgba(59, 130, 246, 0.5)); }
            to { filter: drop-shadow(0 0 6px rgba(59, 130, 246, 0.9)); }
        }
        
        .health-alert {
            animation: alert-pulse 1.5s ease-in-out infinite;
        }
        
        @keyframes alert-pulse {
            0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
            100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
    </style>
</head>

<body class="p-4 sm:p-6 md:p-8">

<div class="max-w-7xl mx-auto">
    <!-- Dashboard Header -->
    <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-8">
        <div class="space-y-2">
            <h1 class="text-4xl sm:text-5xl font-bold gradient-text">
                <i class="fas fa-heartbeat mr-3"></i>Cardiac Diagnosis
            </h1>
            <p class="text-slate-400 text-sm sm:text-base">Real-time cardiac monitoring with automated diagnosis</p>
        </div>
        
        <div class="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <!--<div class="flex items-center text-sm text-gray-400 bg-slate-800/50 px-4 py-3 rounded-lg">-->
            <!--    <i class="fas fa-clock mr-2"></i>-->
            <!--    <span>Last updated: <?= date('M j, Y H:i:s', strtotime($date)) ?></span>-->
            <!--</div>-->
            
            <a href="sensor_fetchdata.php" class="inline-flex items-center justify-center px-5 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-medium rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl">
                <i class="fas fa-history mr-2"></i>
                View History
            </a>
        </div>
    </div>

    <!-- Main Dashboard Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Heart Rate Card -->
        <div class="glass-card rounded-xl p-6 relative overflow-hidden">
            <div class="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-red-500/10"></div>
            <div class="absolute -right-2 -bottom-2 w-16 h-16 rounded-full bg-red-500/5"></div>
            
            <div class="flex justify-between items-start mb-6">
                <div>
                    <div class="flex items-center text-red-400 mb-1">
                        <i class="fas fa-heartbeat text-xl mr-3 heartbeat"></i>
                        <span class="text-lg font-semibold">Heart Rate</span>
                    </div>
                    <p class="text-sm text-slate-400">Beats per minute (BPM)</p>
                </div>
                <span class="status-badge <?= $heart_rate_color ?> bg-opacity-20"><?= $heart_rate_status ?></span>
            </div>
            
            <div class="mt-4">
                <div class="text-5xl font-bold text-red-300 mb-2 animate__animated animate__fadeIn data-point">
                    <?= $value1 ?>
                    <span class="text-2xl text-slate-400">BPM</span>
                </div>
            </div>
        </div>

        <!-- Beat Spacing Card -->
        <div class="glass-card rounded-xl p-6 relative overflow-hidden">
            <div class="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-purple-500/10"></div>
            <div class="absolute -right-2 -bottom-2 w-16 h-16 rounded-full bg-purple-500/5"></div>
            
            <div class="flex justify-between items-start mb-6">
                <div>
                    <div class="flex items-center text-purple-400 mb-1">
                        <i class="fas fa-wave-square text-xl mr-3"></i>
                        <span class="text-lg font-semibold">Beat Spacing</span>
                    </div>
                    <p class="text-sm text-slate-400">Interval between beats</p>
                </div>
                <span class="status-badge text-purple-400 bg-purple-400/20">Stable</span>
            </div>
            
            <div class="mt-4">
                <div class="text-5xl font-bold text-purple-300 mb-2 animate__animated animate__fadeIn data-point">
                    <?= $value2 ?>
                    <span class="text-2xl text-slate-400">ms</span>
                </div>
               
            </div>
        </div>

        <!-- Rhythm Variation Card -->
        <div class="glass-card rounded-xl p-6 relative overflow-hidden">
            <div class="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-blue-500/10"></div>
            <div class="absolute -right-2 -bottom-2 w-16 h-16 rounded-full bg-blue-500/5"></div>
            
            <div class="flex justify-between items-start mb-6">
                <div>
                    <div class="flex items-center text-blue-400 mb-1">
                        <i class="fas fa-random text-xl mr-3"></i>
                        <span class="text-lg font-semibold">Rhythm Variation</span>
                    </div>
                    <p class="text-sm text-slate-400">Heart rhythm consistency</p>
                </div>
            </div>
            
            <div class="mt-4">
                <div class="text-5xl font-bold text-blue-300 mb-2 animate__animated animate__fadeIn data-point">
                    <?= $value3 ?>
                    <span class="text-2xl text-slate-400">%</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Second Row of Parameters -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <!-- Contraction Time -->
        <div class="glass-card rounded-xl p-5">
            <div class="flex items-center text-green-400 mb-3">
                <i class="fas fa-compress-arrows-alt text-lg mr-2"></i>
                <span class="font-semibold">Contraction Time</span>
            </div>
            <div class="text-3xl font-bold text-green-300">
                <?= $value4 ?>
                <span class="text-lg text-slate-400">ms</span>
            </div>
        </div>

        <!-- Baseline Shift -->
        <div class="glass-card rounded-xl p-5">
            <div class="flex items-center text-yellow-400 mb-3">
                <i class="fas fa-arrows-alt-h text-lg mr-2"></i>
                <span class="font-semibold">Baseline Shift</span>
            </div>
            <div class="text-3xl font-bold text-yellow-300">
                <?= $value5 ?>
                <span class="text-lg text-slate-400">mV</span>
            </div>
        </div>

        <!-- Signal Strength -->
        <div class="glass-card rounded-xl p-5">
            <div class="flex items-center text-pink-400 mb-3">
                <i class="fas fa-signal text-lg mr-2"></i>
                <span class="font-semibold">Signal Strength</span>
            </div>
            <div class="text-3xl font-bold text-pink-300">
                <?= $value6 ?>
                <span class="text-lg text-slate-400">dB</span>
            </div>
        </div>

        <!-- Variability -->
        <div class="glass-card rounded-xl p-5">
            <div class="flex items-center text-cyan-400 mb-3">
                <i class="fas fa-chart-line text-lg mr-2"></i>
                <span class="font-semibold">Variability</span>
            </div>
            <div class="text-3xl font-bold text-cyan-300">
                <?= $value7 ?>
                <span class="text-lg text-slate-400">%</span>
            </div>
        </div>
    </div>

<!-- Prediction Card -->
<div class="glass-card rounded-xl p-5">
    <div class="flex items-center <?= $prediction_color ?> mb-3">
        <i class="fas fa-chart-line text-lg mr-2"></i>
        <span class="font-semibold">Prediction</span>
    </div>
    <div class="text-3xl font-bold <?= $prediction_color ?>">
        <?= $prediction_display ?>
    </div>
</div>

        <!-- Baseline Shift -->
        <div class="glass-card rounded-xl p-5">
            <div class="flex items-center text-yellow-400 mb-3">
                <i class="fas fa-clock text-lg mr-2"></i>
                <span class="font-semibold">Last updated</span>
            </div>
            <div class="text-3xl font-bold text-yellow-300">
                <?= date('M j, Y H:i:s', strtotime($date)) ?>
                <span class="text-lg text-slate-400"></span>
            </div>
        </div>

    </div>

    <!-- Graph Section - 3 Graphs -->
    <div class="grid grid-cols-1 lg:grid-cols-1 gap-6 mb-8">
        <!-- Graph 1: Heart Rate & Variability -->
        <div class="glass-card p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-semibold text-white">
                    <i class="fas fa-heartbeat mr-2"></i>Heart Rate & Variability
                </h3>
                <div class="flex items-center text-sm text-slate-400">
                    <div class="w-3 h-3 rounded-full bg-red-500 mr-1"></div> HR
                    <div class="w-3 h-3 rounded-full bg-blue-500 mx-3 mr-1"></div> Variability
                </div>
            </div>
            <div class="chart-container">
                <canvas id="heartRateChart"></canvas>
            </div>
        </div>

        <!-- Graph 2: Beat Analysis -->
        <div class="glass-card p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-semibold text-white">
                    <i class="fas fa-wave-square mr-2"></i>Beat Spacing & Signal Strength
                </h3>
                <div class="flex items-center text-sm text-slate-400">
                    <div class="w-3 h-3 rounded-full bg-purple-500 mr-1"></div> Beat Spacing
                    <div class="w-3 h-3 rounded-full bg-green-500 mx-3 mr-1"></div> Signal Strength
                </div>
            </div>
            <div class="chart-container">
                <canvas id="beatAnalysisChart"></canvas>
            </div>
        </div>

        <!-- Graph 3: Signal Quality -->
        <div class="glass-card p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-semibold text-white">
                    <i class="fas fa-signal mr-2"></i>Rhythm & Contraction Time & Baseline Shift
                </h3>
                <div class="flex items-center text-sm text-slate-400">
                    <div class="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div> Rhythm
                    <div class="w-3 h-3 rounded-full bg-pink-500 mx-3 mr-1"></div> Contraction Time
                    <div class="w-3 h-3 rounded-full bg-purple-500 mx-3 mr-1"></div> Baseline Shift
                </div>
            </div>
            <div class="chart-container">
                <canvas id="signalQualityChart"></canvas>
            </div>
        </div>
    </div>

</div>

<script>
    // Initialize charts when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        const data_value1 = <?php echo json_encode($data_value1); ?>;
        const data_value2 = <?php echo json_encode($data_value2); ?>;
        const data_value3 = <?php echo json_encode($data_value3); ?>;
        const data_value4 = <?php echo json_encode($data_value4); ?>;
        const data_value5 = <?php echo json_encode($data_value5); ?>;
        const data_value6 = <?php echo json_encode($data_value6); ?>;
        const data_value7 = <?php echo json_encode($data_value7); ?>;
        const data_time = <?php echo json_encode($data_time); ?>;
        
        // Chart configuration
        const chartConfig = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleColor: '#f8fafc',
                    bodyColor: '#f8fafc',
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    borderWidth: 1,
                    padding: 12,
                    boxPadding: 6,
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: { 
                        color: 'rgba(255, 255, 255, 0.5)',
                        maxTicksLimit: 8,
                        font: {
                            size: 10
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: { 
                        color: 'rgba(255, 255, 255, 0.5)',
                        font: {
                            size: 10
                        }
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            elements: {
                line: {
                    tension: 0.4
                },
                point: {
                    radius: 0,
                    hoverRadius: 4
                }
            }
        };
        
        // Chart 1: Heart Rate & Variability
        const heartRateCtx = document.getElementById('heartRateChart').getContext('2d');
        new Chart(heartRateCtx, {
            type: 'line',
            data: {
                labels: data_time,
                datasets: [
                    {
                        label: 'Heart Rate',
                        data: data_value1,
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        borderWidth: 2,
                        fill: true
                    },
                    {
                        label: 'Variability',
                        data: data_value7,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.05)',
                        borderWidth: 2,
                        fill: true
                    }
                ]
            },
            options: chartConfig
        });
        
        // Chart 2: Beat Analysis
        const beatAnalysisCtx = document.getElementById('beatAnalysisChart').getContext('2d');
        new Chart(beatAnalysisCtx, {
            type: 'line',
            data: {
                labels: data_time,
                datasets: [
                    {
                        label: 'Beat Spacing',
                        data: data_value2,
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(139, 92, 246, 0.1)',
                        borderWidth: 2,
                        fill: true
                    },
                    {
                        label: 'Signal Strength',
                        data: data_value6,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.05)',
                        borderWidth: 2,
                        fill: true
                    }
                ]
            },
            options: chartConfig
        });
        
        // Chart 3: Rhythm & Contraction  & Baseline Shift
        const signalQualityCtx = document.getElementById('signalQualityChart').getContext('2d');
        new Chart(signalQualityCtx, {
            type: 'line',
            data: {
                labels: data_time,
                datasets: [
                    {
                        label: 'Rhythm',
                        data: data_value3,
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        borderWidth: 2,
                        fill: true
                    },
                    {
                        label: 'Contraction',
                        data: data_value4,
                        borderColor: '#ec4899',
                        backgroundColor: 'rgba(236, 72, 153, 0.05)',
                        borderWidth: 2,
                        fill: true
                    },
                    {
                        label: 'Baseline Shift',
                        data: data_value5,
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(236, 72, 153, 0.05)',
                        borderWidth: 2,
                        fill: true
                    }
                ]
            },
            options: chartConfig
        });
        
        // Add animation to data cards
        const dataCards = document.querySelectorAll('.glass-card');
        dataCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.classList.add('animate__animated', 'animate__pulse');
            });
            card.addEventListener('mouseleave', () => {
                card.classList.remove('animate__animated', 'animate__pulse');
            });
        });
        
        // Update time display every second
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', { 
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            const dateString = now.toLocaleDateString('en-US', {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
            
            // Update any time displays if needed
            const timeElements = document.querySelectorAll('.current-time');
            timeElements.forEach(el => {
                el.textContent = `${dateString} ${timeString}`;
            });
        }
        
        setInterval(updateTime, 1000);
        updateTime();
    });
</script>
</body>
</html>