<?php
include "connection.php";

$value1=$_POST['value1'];

        date_default_timezone_set('Asia/Kolkata');
        $timestamp = date("Y-m-d H:i:s");
        
        $sql = "INSERT INTO `4686_1` (value1,reading_time)
        VALUES ('$value1','$timestamp')";

        $result=mysqli_query($conn,$sql);
        
        if ($result) {
            echo "New record created successfully";
        } 
        else {
            echo "Values Are Not Entered";
        }
        
        
        $sql4="SELECT * FROM `4686_1`";
        $result4=mysqli_query($conn,$sql4);
        
        if(mysqli_num_rows($result4)>50){
         $sql51="DELETE FROM `4686_1` ORDER BY id ASC limit 1";
         $result51=mysqli_query($conn,$sql51);
           if($result51){
             echo "deleted Successfully";
           }
        }

?>
