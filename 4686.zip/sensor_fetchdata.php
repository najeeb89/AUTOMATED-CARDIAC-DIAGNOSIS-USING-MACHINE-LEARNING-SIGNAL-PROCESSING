<?php
include("connection.php");
$sql = "SELECT * FROM `4686` ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>History | Cardiac Diagnosis</title>

  <!-- Fonts & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    :root {
      --primary: #3b82f6;
      --secondary: #8b5cf6;
      --tertiary: #ec4899;
      --dark-bg: #0f172a;
      --card-bg: rgba(15, 23, 42, 0.6);
      --border-color: rgba(255, 255, 255, 0.1);
      --text: #f8fafc;
      --text-light: #cbd5e1;
      --text-lighter: #94a3b8;
      --danger: #ef4444;
      --warning: #f59e0b;
      --success: #10b981;
      --shadow: rgba(0, 0, 0, 0.25);
    }

    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: var(--text);
      min-height: 100vh;
    }

    header {
      background: rgba(15, 23, 42, 0.8);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border-color);
      padding: 1rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 10;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .logo-icon {
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      width: 36px;
      height: 36px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .logo-text {
      font-size: 1.5rem;
      font-weight: 700;
      background: linear-gradient(90deg, var(--primary), var(--secondary), var(--tertiary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
      background-size: 200% auto;
      animation: gradient 3s ease infinite;
    }

    @keyframes gradient {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .btn-dashboard {
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
      transition: all 0.3s;
      text-decoration: none;
      box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
    }

    .btn-dashboard:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }

    .page-header {
      text-align: center;
      margin: 2rem 0 3rem;
    }

    .page-title {
      font-size: 2.5rem;
      font-weight: 700;
      margin: 0 0 0.5rem 0;
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      -webkit-background-clip: text;
      background-clip: text;
      color: transparent;
    }

    .page-subtitle {
      color: var(--text-light);
      font-size: 1rem;
      margin: 0;
    }

    .glass-card {
      background: var(--card-bg);
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 8px 32px var(--shadow);
      margin-bottom: 3rem;
    }

    .card-header {
      padding: 1.5rem 2rem;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(15, 23, 42, 0.8);
    }

    .card-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .table-container {
      overflow-x: auto;
      border-radius: 0 0 16px 16px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.95rem;
    }

    th {
      background: linear-gradient(90deg, rgba(59, 130, 246, 0.2), rgba(139, 92, 246, 0.2));
      color: var(--text);
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.8rem;
      letter-spacing: 0.5px;
      padding: 1.25rem 1.5rem;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }

    td {
      padding: 1.25rem 1.5rem;
      border-bottom: 1px solid var(--border-color);
      color: var(--text-light);
    }

    tr {
      transition: all 0.3s ease;
      background: transparent;
    }

    tr:hover {
      background: rgba(59, 130, 246, 0.05);
    }

    tr:nth-child(even) {
      background: rgba(255, 255, 255, 0.02);
    }

    tr:nth-child(even):hover {
      background: rgba(59, 130, 246, 0.08);
    }

    .value-cell {
      font-weight: 500;
      font-family: 'Courier New', monospace;
    }

    .heart-rate {
      color: #ef4444;
    }

    .beat-spacing {
      color: #8b5cf6;
    }

    .rhythm-variation {
      color: #3b82f6;
    }

    .contraction-time {
      color: #10b981;
    }

    .baseline-shift {
      color: #f59e0b;
    }

    .signal-strength {
      color: #ec4899;
    }

    .variability {
      color: #06b6d4;
    }

    .timestamp {
      color: var(--text-lighter);
      font-size: 0.9rem;
    }

    .empty-state {
      padding: 3rem 2rem;
      text-align: center;
      color: var(--text-light);
    }

    .empty-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }

    .stats-bar {
      display: flex;
      justify-content: space-between;
      background: rgba(15, 23, 42, 0.8);
      padding: 1rem 2rem;
      border-bottom: 1px solid var(--border-color);
      color: var(--text-light);
      font-size: 0.9rem;
    }

    .stats-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .stats-value {
      color: var(--text);
      font-weight: 600;
    }

    /* Scrollbar styling */
    ::-webkit-scrollbar {
      width: 8px;
      height: 8px;
    }

    ::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb {
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      border-radius: 4px;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .container {
        padding: 1rem;
      }
      
      .page-title {
        font-size: 2rem;
      }
      
      .card-header {
        padding: 1.25rem;
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
      }
      
      th, td {
        padding: 1rem;
      }
      
      header {
        padding: 1rem;
      }
      
      .stats-bar {
        flex-direction: column;
        gap: 0.75rem;
        padding: 1rem;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">
      <div class="logo-icon">
        <i class="fas fa-heartbeat" style="color: white;"></i>
      </div>
      <div class="logo-text">Cardiac Diagnosis</div>
    </div>
    <a href="index.php" class="btn-dashboard">
      <i class="fas fa-arrow-left"></i>
      <span>Back to Dashboard</span>
    </a>
  </header>

  <div class="container">
    <div class="page-header">
      <h1 class="page-title">Cardiac Diagnosis History</h1>
      <p class="page-subtitle">Complete record of all sensor data readings and cardiac metrics</p>
    </div>

    <?php
    if (mysqli_num_rows($result) > 0) {
      $total_records = mysqli_num_rows($result);
      $first_record = mysqli_fetch_assoc(mysqli_query($conn, "SELECT reading_time FROM `4686` ORDER BY id ASC LIMIT 1"));
      $last_record = mysqli_fetch_assoc(mysqli_query($conn, "SELECT reading_time FROM `4686` ORDER BY id DESC LIMIT 1"));
      
      mysqli_data_seek($result, 0); // Reset pointer to beginning
    ?>

    <div class="glass-card">
      <div class="card-header">
        <h3 class="card-title">
          <i class="fas fa-history"></i>
          Sensor Data History
        </h3>
        <div style="color: var(--text-light); font-size: 0.9rem;">
          Showing latest <?php echo min(100, $total_records); ?> records
        </div>
      </div>
      
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th><i class="fas fa-heartbeat"></i> Heart Rate</th>
              <th><i class="fas fa-wave-square"></i> Beat Spacing</th>
              <th><i class="fas fa-random"></i> Rhythm Variation</th>
              <th><i class="fas fa-compress-arrows-alt"></i> Contraction Time</th>
              <th><i class="fas fa-arrows-alt-h"></i> Baseline Shift</th>
              <th><i class="fas fa-signal"></i> Signal Strength</th>
              <th><i class="fas fa-chart-line"></i> Variability</th>
              <th><i class="fas fa-clock"></i> Reading Time</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $i = 1;
            while ($row = mysqli_fetch_assoc($result) ) {
                $x = $row['value1'];
                $y = $row['value2'];
                $z = $row['value3'];
                $rx = $row['value4'];
                $ry = $row['value5'];
                $rz = $row['value6'];
                $ls = $row['value7'];
                $timestamp = date('M j, H:i:s', strtotime($row['reading_time']));
              
                echo '<tr>';
                echo '<td class="timestamp">' . $i++ . '</td>';
                echo '<td class="value-cell ' . $heart_rate_class . '">' . $x . ' <span style="font-size: 0.8em; color: var(--text-lighter);">BPM</span></td>';
                echo '<td class="value-cell beat-spacing">' . $y . ' <span style="font-size: 0.8em; color: var(--text-lighter);">ms</span></td>';
                echo '<td class="value-cell rhythm-variation">' . $z . ' <span style="font-size: 0.8em; color: var(--text-lighter);">%</span></td>';
                echo '<td class="value-cell contraction-time">' . $rx . ' <span style="font-size: 0.8em; color: var(--text-lighter);">ms</span></td>';
                echo '<td class="value-cell baseline-shift">' . $ry . ' <span style="font-size: 0.8em; color: var(--text-lighter);">mV</span></td>';
                echo '<td class="value-cell signal-strength">' . $rz . ' <span style="font-size: 0.8em; color: var(--text-lighter);">dB</span></td>';
                echo '<td class="value-cell variability">' . $ls . ' <span style="font-size: 0.8em; color: var(--text-lighter);">%</span></td>';
                echo '<td class="timestamp">' . $timestamp . '</td>';
                echo '</tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
    
    <?php } else { ?>
    
    <div class="glass-card">
      <div class="empty-state">
        <div class="empty-icon">
          <i class="fas fa-database"></i>
        </div>
        <h3 style="margin-bottom: 0.5rem; color: var(--text);">No Data Available</h3>
        <p style="margin: 0; color: var(--text-light);">No sensor data records found. Start monitoring to see data here.</p>
        <a href="index.php" class="btn-dashboard" style="margin-top: 1.5rem; display: inline-block;">
          <i class="fas fa-play-circle"></i>
          <span>Start Monitoring</span>
        </a>
      </div>
    </div>
    
    <?php } ?>
  </div>

  <script>
    // Add hover effects to table rows
    document.addEventListener('DOMContentLoaded', function() {
      const rows = document.querySelectorAll('tbody tr');
      
      rows.forEach(row => {
        row.addEventListener('mouseenter', function() {
          this.style.transform = 'translateX(4px)';
        });
        
        row.addEventListener('mouseleave', function() {
          this.style.transform = 'translateX(0)';
        });
      });
      
      // Add animation to page load
      const cards = document.querySelectorAll('.glass-card');
      cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
          card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, index * 100);
      });
    });
  </script>
</body>
</html>