<?php
include "connection.php";

$value1=$_POST['value1'];
$value2=$_POST['value2'];
$value3=$_POST['value3'];
$value4=$_POST['value4'];
$value5=$_POST['value5'];
$value6=$_POST['value6'];
$value7=$_POST['value7'];

$a=array("value1"=>$value1,"value2"=>$value2,"value3"=>$value3,"value4"=>$value4,"value5"=>$value5,"value6"=>$value6,"value7"=>$value7);
$b=json_encode($a);
file_put_contents("light.json",$b);

        date_default_timezone_set('Asia/Kolkata');
        $timestamp = date("Y-m-d H:i:s");
        
        $sql = "INSERT INTO `4686` (value1,value2,value3,value4,value5,value6,value7,reading_time)
        VALUES ('$value1','$value2', '$value3','$value4','$value5', '$value6','$value7', '$timestamp')";

        $result=mysqli_query($conn,$sql);
        
        if ($result) {
            echo "New record created successfully";
        } 
        else {
            echo "Values Are Not Entered";
        }
        
        
        $sql4="SELECT * FROM `4686`";
        $result4=mysqli_query($conn,$sql4);
        
        if(mysqli_num_rows($result4)>50){
         $sql51="DELETE FROM `4686` ORDER BY id ASC limit 1";
         $result51=mysqli_query($conn,$sql51);
           if($result51){
             echo "deleted Successfully";
           }
        }

?>
